#include <stdio.h>
#include <stdlib.h>
#include <time.h>
void round1(int*hp,char s);
void round2(int*hp,char s);
void round3(int*hp,char s);
void round4(int*hp,char s);
void round5(int*hp,char s);
void round6(int*hp,char s);
void round7(int*hp,char s);
void round8(int*hp,char s);
void round9(int*hp,char s);
void round10(int*hp,char s);
int main()
{
	srand(time(NULL));
	FILE *file=fopen("girog.txt","a");
	int i,j,hert,nan,a;
	char san;
	hert=100;
	for (i=1;i<11;i++){
		printf("round:%d\n",i);
		scanf(" %c",&san);
		switch (i){
			case 1:
				round1(&hert,san);
				if (hert<=0)i=100;
				break;
			case 2:
				round2(&hert,san);
				if (hert<=0)i=100;
				break;
			case 3:
				round3(&hert,san);
				if (hert<=0)i=100;
				break;
			case 4:
				round4(&hert,san);
				if (hert<=0)i=100;
				break;
			case 5:
				round5(&hert,san);
				if (hert<=0)i=100;
				break;
			case 6:
				round6(&hert,san);
				if (hert<=0)i=100;
				break;
			case 7:
				round7(&hert,san);
				if (hert<=0)i=100;
				break;
			case 8:
				round8(&hert,san);
				if (hert<=0)i=100;
				break;
			case 9:
				round9(&hert,san);
				if (hert<=0)i=100;
				break;
			case 10:
				round10(&hert,san);
				if (hert<=0)i=100;
				fprintf(file,"girog %d\n",hert);
				fclose(file);
				break;

		}
	}
	return 0;
}


void round1(int*hp,char s){
	int ran = rand()%100;
	switch (s){
		case 'a':
			if (ran>=30)*hp=*hp+10;
			else *hp=*hp-10;
			break;
		case 'b':
			if (ran>=30)*hp=*hp-50;
			else *hp=*hp+50;
	}
	printf("hp:%d\n",*hp);
}
void round2(int*hp,char s){
	int ran = rand()%100;
	switch (s){
		case 'a':
			if (ran>=10)*hp=*hp+5;
			break;
		case 'b':
			if (ran>=90)*hp=*hp+100;
	}
	printf("hp:%d\n",*hp);

}
void round3(int*hp,char s){	
	int ran = rand()%100;
	switch (s){
		case 'a':
			if (ran>=50)*hp=*hp+20;
			else *hp=*hp-20;
			break;
		case 'b':
			if (ran>=50)*hp=*hp-40;
			else *hp=*hp+40;
	}
	printf("hp:%d\n",*hp);
}
void round4(int*hp,char s){
	int ran = rand()%100;
	switch (s){
		case 'a':
			if (ran>=45)*hp=*hp-45;
			else *hp=*hp+55;
			break;
		case 'b':
			break;
	}
	printf("hp:%d\n",*hp);
}
void round5(int*hp,char s){
	int ran = rand()%100;
	switch (s){
		case 'a':
			if (ran>=10)*hp=*hp+1;
			else *hp=*hp-1000000;
			break;
		case 'b':
			if (ran>=10)*hp=*hp-90;
			else *hp=*hp+90;
	}
	printf("hp:%d\n",*hp);
}
void round6(int*hp,char s){
	int ran = rand()%100;
	switch (s){
		case 'a':
			if (ran>=30)*hp=*hp+10;
			else *hp=*hp-20;
			break;
		case 'b':
			if (ran>=30)*hp=*hp-20;
			else *hp=*hp+30;
	}
	printf("hp:%d\n",*hp);
}
void round7(int*hp,char s){
	int ran = rand()%100;
	switch (s){
		case 'a':
			if (ran>=23)*hp=*hp-7;
			else *hp=*hp+77;
			break;
		case 'b':
			if (ran>=23)*hp=*hp+7;
			else *hp=*hp-77;
	}
	printf("hp:%d\n",*hp);
}
void round8(int*hp,char s){
	int ran = rand()%100;
	switch (s){
		case 'a':
			if (ran>=60)*hp=*hp*2;
			else *hp=*hp/2;
			break;
		case 'b':
			if (ran>=60)*hp=*hp*3;
			else *hp=*hp/3;
	}
	printf("hp:%d\n",*hp);
}
void round9(int*hp,char s){
	int ran = rand()%100;
	switch (s){
		case 'a':
			if (ran>=95)*hp=*hp*8;
			else *hp=*hp-150;
			break;
		case 'b':
			if (ran>=5)*hp=*hp*1.2;
			else *hp=*hp-150;
	}
	printf("hp:%d\n",*hp);
}
void round10(int*hp,char s){
	int ran = rand()%100;
	switch (s){
		case 'a':
			if (ran>=98)*hp=*hp*22;
			else *hp=*hp*2;
			break;
		case 'b':
			if (ran>=99)*hp=*hp*44;
			else *hp=*hp*1.5;
	}
	printf("hp:%d\n",*hp);
}

